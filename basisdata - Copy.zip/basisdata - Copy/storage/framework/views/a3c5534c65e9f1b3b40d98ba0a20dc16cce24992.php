<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Styles -->
    
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <!-- Optionally, add any other stylesheets you need -->
</head>
<body>
    <div id="app">
        <!-- Navbar / Header -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><?php echo e(config('app.name', 'Laravel')); ?></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('posts.index')); ?>">Posts</a>
                        </li>
                        <?php if(auth()->guard()->check()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('posts.create')); ?>">Create Post</a>
                            </li>
                            <li class="nav-item">
                                
                            </li>
                            
                                <?php echo csrf_field(); ?>
                            </form>
                        <?php else: ?>
                            <li class="nav-item">
                                
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Main content -->
        <main class="container my-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <!-- Footer -->
        <footer class="bg-light py-4">
            <div class="container text-center">
                <p>&copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name', 'Laravel')); ?>. All rights reserved.</p>
            </div>
        </footer>
    </div>

    <!-- Scripts -->
    
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>

    <!-- Optionally, add other scripts if needed -->
</body>
</html>
<?php /**PATH C:\basisdata\resources\views/layouts/app.blade.php ENDPATH**/ ?>