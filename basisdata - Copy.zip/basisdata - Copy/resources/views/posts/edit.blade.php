@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Edit Post</h1>
    <form action="{{ route('posts.update', $post->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="form-group">
            <label for="title">Judul</label>
            <input type="text" name="title" id="title" class="form-control" value="{{ $post->title }}" required>
        </div>
        <div class="form-group">
            <label for="slug">Slug</label>
            <input type="text" name="slug" id="slug" class="form-control" value="{{ $post->slug }}" required>
        </div>
        <div class="form-group">
            <label for="user_id">User ID</label>
            <input type="number" name="user_id" id="user_id" class="form-control" value="{{ $post->user_id }}" required>
        </div>
        <div class="form-group">
            <label for="content">Konten</label>
            <textarea name="content" id="content" class="form-control" rows="5" required>{{ $post->content }}</textarea>
        </div>
        <div class="form-group">
            <label for="image">Gambar</label>
            <input type="text" name="image" id="image" class="form-control" value="{{ $post->image }}">
        </div>
        <div class="form-group">
            <label for="aktif">Aktif</label>
            <select name="aktif" id="aktif" class="form-control">
                <option value="Y" {{ $post->aktif == 'Y' ? 'selected' : '' }}>Ya</option>
                <option value="N" {{ $post->aktif == 'N' ? 'selected' : '' }}>Tidak</option>
            </select>
        </div>
        <div class="form-group">
            <label for="status">Status</label>
            <select name="status" id="status" class="form-control">
                <option value="publish" {{ $post->status == 'publish' ? 'selected' : '' }}>Publish</option>
                <option value="draft" {{ $post->status == 'draft' ? 'selected' : '' }}>Draft</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
@endsection
