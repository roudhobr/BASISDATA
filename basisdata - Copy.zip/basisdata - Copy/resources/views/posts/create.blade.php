@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Tambah Post</h1>
    <form action="{{ route('posts.store') }}" method="POST">
        @csrf
        <div class="form-group">
            <label for="title">Judul</label>
            <input type="text" name="title" id="title" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="slug">Slug</label>
            <input type="text" name="slug" id="slug" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="user_id">User ID</label>
            <input type="number" name="user_id" id="user_id" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="content">Konten</label>
            <textarea name="content" id="content" class="form-control" rows="5" required></textarea>
        </div>
        <div class="form-group">
            <label for="image">Gambar</label>
            <input type="text" name="image" id="image" class="form-control">
        </div>
        <div class="form-group">
            <label for="aktif">Aktif</label>
            <select name="aktif" id="aktif" class="form-control">
                <option value="Y">Ya</option>
                <option value="N">Tidak</option>
            </select>
        </div>
        <div class="form-group">
            <label for="status">Status</label>
            <select name="status" id="status" class="form-control">
                <option value="publish">Publish</option>
                <option value="draft">Draft</option>
            </select>
        </div>
        <button type="submit" class="btn btn-success">Simpan</button>
    </form>
</div>
@endsection
